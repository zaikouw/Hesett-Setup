const express = require('express');
const cors = require('cors');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();
const PORT = 3001;

// Enable CORS for all routes
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
}));

// Proxy middleware configuration
const proxyOptions = {
  target: 'http://192.168.58.115:80',
  changeOrigin: true,
  pathRewrite: {
    '^/esp32': '', // Remove /esp32 prefix when forwarding to ESP32
  },
  onProxyRes: function (proxyRes, req, res) {
    // Add CORS headers to the response
    proxyRes.headers['Access-Control-Allow-Origin'] = '*';
    proxyRes.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS';
    proxyRes.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, X-Requested-With';
  }
};

// Proxy all requests to ESP32
app.use('/esp32', createProxyMiddleware(proxyOptions));

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'CORS Proxy is running', target: 'http://192.168.58.115:80' });
});

app.listen(PORT, () => {
  console.log(`🚀 CORS Proxy running on http://localhost:${PORT}`);
  console.log(`📡 Proxying requests to ESP32 at http://192.168.58.115:80`);
  console.log(`🌐 Access ESP32 via: http://localhost:${PORT}/esp32/status`);
});

// Handle errors
app.on('error', (err) => {
  console.error('❌ Proxy error:', err);
}); 