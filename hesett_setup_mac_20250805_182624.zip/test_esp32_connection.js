const http = require('http');

const ESP32_IP = '192.168.58.115';
const ESP32_PORT = 80;

// Test functions
async function testEndpoint(endpoint, method = 'GET', data = null) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: ESP32_IP,
      port: ESP32_PORT,
      path: endpoint,
      method: method,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json'
      }
    };

    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => {
        body += chunk;
      });
      res.on('end', () => {
        console.log(`✅ ${method} ${endpoint}: ${res.statusCode}`);
        console.log(`   Response: ${body}`);
        resolve({ statusCode: res.statusCode, body: body });
      });
    });

    req.on('error', (err) => {
      console.log(`❌ ${method} ${endpoint}: ${err.message}`);
      reject(err);
    });

    if (data) {
      req.write(data);
    }
    req.end();
  });
}

async function runTests() {
  console.log('🧪 Testing ESP32 Connection');
  console.log('============================');
  console.log(`Target: http://${ESP32_IP}:${ESP32_PORT}`);
  console.log('');

  try {
    // Test 1: Status endpoint
    console.log('1️⃣ Testing /status endpoint...');
    await testEndpoint('/status');
    console.log('');

    // Test 2: IP endpoint
    console.log('2️⃣ Testing /ip endpoint...');
    await testEndpoint('/ip');
    console.log('');

    // Test 3: Get Restaurant ID
    console.log('3️⃣ Testing /get_restaurant_id endpoint...');
    await testEndpoint('/get_restaurant_id');
    console.log('');

    // Test 4: Set Restaurant ID
    console.log('4️⃣ Testing /set_restaurant_id endpoint...');
    await testEndpoint('/set_restaurant_id', 'POST', 'restaurant_id=TEST_RESTAURANT_123');
    console.log('');

    // Test 5: Start Pairing
    console.log('5️⃣ Testing /start_pairing endpoint...');
    await testEndpoint('/start_pairing', 'POST');
    console.log('');

    // Test 6: Pairing Status
    console.log('6️⃣ Testing /pairing_status endpoint...');
    await testEndpoint('/pairing_status');
    console.log('');

    // Test 7: Stop Pairing
    console.log('7️⃣ Testing /stop_pairing endpoint...');
    await testEndpoint('/stop_pairing', 'POST');
    console.log('');

    // Test 8: Diagnostic
    console.log('8️⃣ Testing /diagnostic endpoint...');
    await testEndpoint('/diagnostic');
    console.log('');

    console.log('🎉 All tests completed!');
    console.log('✅ Your ESP32 is working correctly with the simplified firmware!');

  } catch (error) {
    console.log('❌ Test failed:', error.message);
  }
}

// Run the tests
runTests(); 