# 🚀 Hesett Box Setup for Mac

## Quick Start
1. Extract this ZIP file
2. Double-click `Hesett_Setup_Mac.command`
3. Follow the wizard in your browser
4. Your Hesett Box will be ready in 2 minutes!

## Requirements
- macOS 10.14 or later
- Node.js installed (download from nodejs.org)
- Hesett Box connected via USB

## What's Included
- One-click setup launcher
- Automatic dependency installation
- Beautiful web-based wizard
- Complete Hesett Box configuration

## Support
If you need help, contact your Hesett support person.
